module Lab2 {
}