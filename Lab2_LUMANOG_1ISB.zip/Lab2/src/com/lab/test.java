package com.lab;

public class test {

	public static void main(String[] args) {
		Airport ar1 = new Airport();
		ar1.setName("");
		ar1.setTerminal(0);
		ar1.setDeparture(1300);
		ar1.setArrival(1300);
		
		Airline air = new Airline();
		air.setAirName("");
		air.setDay("");
		air.setCarrier(0);
		
		
		
		//First Part Airport Details
		
		System.out.println("Welcome to The Flight Manager Environment!");
		System.out.println("Please Enter in the Following Fields");
		System.out.println("");
		System.out.println(ar1.getName());
		System.out.println(ar1.getTerminal());
		System.out.println(ar1.getDeparture());
		System.out.println(ar1.getArrival());
		
		System.out.println("Here are your Entered Flight Details"); 
		System.out.println("");
		System.out.println("Airport Name: " + ar1.getName2());
		System.out.println("Terminal Number: " + ar1.getTerminal2());
		System.out.println("Departure Time: " + ar1.getDeparture2());
		System.out.println("Arrival Time: " + ar1.getArrival2());
		
		
		//Second Part Airline Details
		
		System.out.println("Please Enter your Airline Details");
		System.out.println("");
		
		System.out.println(air.getAirName());
		System.out.println(air.getDay());
		System.out.println(air.getCarrier());
		

		System.out.println("Here are your Entered Airline Details");
		System.out.println("");
		//
		System.out.println("You are Riding with: " + air.getAirName2());
		System.out.println("Your Flight Number: " + air.getCarrier2());
		System.out.println("Date of Flight: " + air.getDay2());
		System.out.println("");
		//
		System.out.println("Here are your Full Flight Details");
		System.out.println("");
		System.out.println("Airport Name: " + ar1.getName2());
		System.out.println("Terminal Number: " + ar1.getTerminal2());
		System.out.println("Departure Time: " + ar1.getDeparture2());
		System.out.println("Arrival Time: " + ar1.getArrival2());
		System.out.println("You are Riding with: " + air.getAirName2());
		System.out.println("Your Flight Number: " + air.getCarrier2());
		System.out.println("Date of Flight: " + air.getDay2());
		
		
		
	}

}
