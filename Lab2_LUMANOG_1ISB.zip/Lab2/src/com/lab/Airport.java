package com.lab;

import java.util.Scanner;
//PARENT CLASS
public class Airport {
	Scanner sc = new Scanner(System.in);
	
	private String name;
	private int terminal;
	private int departure;
	private int arrival;
	
	//CONSTRUCTORS
	
	public void Airport () {
		
	}
	public void Airport (String name, int terminal, int departure) {
		this.name = name;
		this.terminal = terminal;
		this.departure = departure;
	}
	
	//SETTERS
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setTerminal (int terminal) {
		this.terminal = terminal;
	}
	
	public void setDeparture (int departure) {
		this.departure = departure;
	}
	
	public void setArrival (int arrival) {
		this.arrival = arrival;
	}
	
	//GETTERS
	
	public String getName() {
		System.out.print("Enter Airport Name: ");
		this.name = sc.nextLine();
		return this.name;
	}
	
	public int getTerminal() {
		System.out.print("Enter Terminal No.: ");
		this.terminal = sc.nextInt();
		return this.terminal;
	}
	
	public int getDeparture() {
		System.out.print("Enter Departure Time: ");
		this.departure = sc.nextInt();
		return this.departure;
	}
	
	public int getArrival() {
		System.out.println("Enter Arrival Time: ");
		this.arrival = sc.nextInt();
		return this.arrival;
	}
	
	//2nd GETTERS to organize
	public String getName2() {
		return this.name;
	}
	public int getTerminal2() {
		return this.terminal;
	}
	public int getDeparture2() {
		return this.departure;
	}
	public int getArrival2() {
		return this.arrival;
	}
	
	
	
	
	
}
