package com.lab;

import java.util.Scanner;
//DAUGHTER CLASS TO AIRPORT 
public class Airline extends Airport {
	Scanner sc = new Scanner(System.in);
	
	private String airName;
	private String day;
	private int carrier;
	
	
	public void Airline() {
		
	}
	
	public void Airline(String airName, String day, int carrier ) {
		this.airName = airName;
		this.carrier = carrier;
		this.day = day;
		
	}
	
	//SETTERS
	
	public void setAirName(String airName) {
		this.airName = airName;
	}
	
	public void setDay(String day) {
		this.day = day;
	}
	
	public void setCarrier(int carrier) {
		this.carrier = carrier;
	}
	
	
	
	//GETTERS
	
	public String getAirName() {
		System.out.println("Enter Airline Name: ");
		this.airName = sc.nextLine();
		return this.airName;
	}
	
	
	public String getDay() {
		System.out.println("Enter Date of Flight: ");
		this.day = sc.nextLine();
		return this.day;
	}
	
	public int getCarrier() {
		System.out.println("Enter Flight No.: ");
		this.carrier = sc.nextInt();
		return this.carrier;
	}
	
	
	
	//2nd GETTERS to ORGANIZE
	
	public String getAirName2() {
		return this.airName;
	}
	public String getDay2() {
		return this.day;
	}
	public int getCarrier2() {
		return this.carrier;
	}
	
	
	
	
	
	
}
